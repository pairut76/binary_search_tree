

#include <iostream>
#include "HashSet.hpp"
using namespace std;

int test()
{
	cout<<"------------testing------------"<<endl;
	return 0;
}